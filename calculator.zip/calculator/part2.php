<?php 
class calculation{
	function add($a,$b){
		echo "Sumation: ".($a+$b)."<br>";

	}
	function sub($a,$b){
		echo "Subtraction: ".($a-$b)."<br>";

	}
	function mul($a,$b){
		echo "Multiplication: ".($a*$b)."<br>";

	}
	function div($a,$b){
		echo "Division: ".($a/$b)."<br>";

	}
}

 ?>