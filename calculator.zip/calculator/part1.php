<?php 
include ("part2.php");

 ?>

<form action="" method="POST">
	<table>
		<tr>
			<td>Enter First Number: </td>
			<td><input type="number" name="num"></td>
		</tr>
		<tr>
			<td>Enter Second Number: </td>
			<td><input type="number" name="num2"></td>
		</tr>
		<tr>
			<td></td>
			<td><input type="submit" name="calculation" value="calculation"></td>
		</tr>
	</table>
</form>

<?php 
if (isset($_POST['calculation'])) {
	$numOne = $_POST['num'];
	$numTwo = $_POST['num2'];

	if (empty($numOne) or empty($numTwo)) {
		echo "<span style=color:red;>Must Fill Number Box</span>";
	}else{

	$cal=new calculation;
	$cal ->add($numOne,$numTwo);
	$cal ->sub($numOne,$numTwo);
	$cal ->mul($numOne,$numTwo);
	$cal ->div($numOne,$numTwo);
	}
}

 ?>